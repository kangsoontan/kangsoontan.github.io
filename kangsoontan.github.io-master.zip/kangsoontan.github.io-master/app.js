
var main = function(){

	$('.option').click(function(){
		$('.home').hide();
		$('.about').hide();
		$('.skills').hide();
		$('.school').hide();
		$('.projects').hide();
		$('.Resume').hide();
		$('.option').removeClass('current-select');
		$(this).addClass('current-select');
		$('.option').animate({fontSize: "100%"}, 200).removeClass('current-select');
		$(this).animate({fontSize: "125%"}, 200).addClass('current-select');
		var text = $(this).text().trim();
		if (text === "Home"){
			$('.home').fadeIn(600);
		} else if (text === "Resume"){
			$('.Resume').fadeIn(600);
		}else if (text === "About"){
			$('.about').fadeIn(600);
		}else if (text === "Skills"){
			$('.skills').fadeIn(600);
			loadGeneral();
		}else if (text === "School"){
			$('.school').fadeIn(600);
		}else if (text === "Projects"){
			$('.projects').fadeIn(600);
		}
	});

	/*$('.cancel').click(function(){
		$('#resume').fadeOut(600);
	});*/

	$('.skillsOptions').click(function(){
		
		var skillsName = $(this).text().trim();
		if (skillsName === "Overview"){
			$('.general').hide();
			$('.languages').hide();
			$('.plugins').hide();
			$('.devTools').hide();
			$('.designTools').hide();
			$('#general').hide();
			$('#languages').hide();
			$('#plugins').hide();
			$('#devTools').hide();
			$('#designTools').hide();
			$('.general').fadeIn(600);
			$('#general').fadeIn(600);
			loadGeneral();
		}
		if (skillsName === "Programming Languages"){
			$('.general').hide();
			$('.languages').hide();
			$('.plugins').hide();
			$('.devTools').hide();
			$('.designTools').hide();
			$('#general').hide();
			$('#languages').hide();
			$('#plugins').hide();
			$('#devTools').hide();
			$('#designTools').hide();
			$('#languages').fadeIn(600);
			$('.languages').fadeIn(600);
			loadProgrammingLanguagesData();
		}
		if (skillsName === "Libraries and Plugins"){
			$('.general').hide();
			$('.languages').hide();
			$('.plugins').hide();
			$('.devTools').hide();
			$('.designTools').hide();
			$('#general').hide();
			$('#languages').hide();
			$('#plugins').hide();
			$('#devTools').hide();
			$('#designTools').hide();
			$('#plugins').fadeIn(600);
			$('.plugins').fadeIn(600);
			loadLibrariesAndPlugins();
		}
		if (skillsName === "Developers' Tools"){
			$('.general').hide();
			$('.languages').hide();
			$('.plugins').hide();
			$('.devTools').hide();
			$('.designTools').hide();
			$('#general').hide();
			$('#languages').hide();
			$('#plugins').hide();
			$('#devTools').hide();
			$('#designTools').hide();
			$('#devTools').fadeIn(600);
			$('.devTools').fadeIn(600);
			loadDevelopersToolsData();
		}
		if (skillsName === "Designers' Tools"){
			$('.general').hide();
			$('.languages').hide();
			$('.plugins').hide();
			$('.devTools').hide();
			$('.designTools').hide();
			$('#general').hide();
			$('#languages').hide();
			$('#plugins').hide();
			$('#devTools').hide();
			$('#designTools').hide();
			$('#designTools').fadeIn(600);
			$('.designTools').fadeIn(600);
			loadDesignersToolsData();
		}
		/*if (skillsName === "Resume"){
			$('#resume').fadeIn(600);
		}*/
	});

	$('.thumbnail').click(function(){
		$('.nusgdg').hide();
		$('.tGuitar').hide();
		$('.soc').hide()
		$('.stargazers').hide();
		$('#pewbg').hide();
		$('#bbqbg').hide();
		$('#mousebg').hide();
		$('#simbg').hide();
		$('#gdgbg').hide();
		$('#socbg').hide();
		$('#tguitarbg').hide();
		$('#stargazersbg').hide();
		$('#portfoliobg').hide();
		$('#momogachabg').hide();
		$('#rollinggobg').hide();
		$('#binobg').hide();
		$('.pew').hide();
		$('.bbqtime').hide();
		$('.ssim2015').hide();
		$('.minutemouse').hide();
		$('.portfolio').hide();
		$('.momogacha').hide();
		$('.rollinggo').hide();
		$('.bino').hide();
		var projectName = $(this).text().trim();
		if (projectName === "PEW"){
			$('.pew').fadeIn(600);
			$('#pewbg').fadeIn(600);
		}
		if (projectName === "BBQTime"){
			$('.bbqtime').fadeIn(600);
			$('#bbqbg').fadeIn(600);
		}
		if (projectName === "SSim2015"){
			$('.ssim2015').fadeIn(600);
			$('#simbg').fadeIn(600);
		}
		if (projectName === "MinuteMouse"){
			$('#mousebg').fadeIn(600);
			$('.minutemouse').fadeIn(600);
		}
		if (projectName === "Portfolio"){
			$('#portfoliobg').fadeIn(600);
			$('.portfolio').fadeIn(600);
		}
		if (projectName === "MomoGacha"){
			$('#momogachabg').fadeIn(600);
			$('.momogacha').fadeIn(600);
		}
		if (projectName === "RollingGO"){
			$('#rollinggobg').fadeIn(600);
			$('.rollinggo').fadeIn(600);
		}
		if (projectName === "Bino&Friends"){
			$('#binobg').fadeIn(600);
			$('.bino').fadeIn(600);
		}
		if (projectName === "NUS Games Development Group"){
			$('#gdgbg').fadeIn(600);
			$('.nusgdg').fadeIn(600);
		}
		if (projectName === "NUS School of Computing"){
			$('.soc').fadeIn(600);
			$('#socbg').fadeIn(600);
		}
		if (projectName === "Tembusu Guitar Ensemble"){
			$('.tGuitar').fadeIn(600);
			$('#tguitarbg').fadeIn(600);
		}
		if (projectName === "Tembusu Stargazers Group"){
			$('.stargazers').fadeIn(600);
			$('#stargazersbg').fadeIn(600);
		}
	});
}

function loadGeneral(){
	var data = {
	    labels: ["Programming", "Writing", "Art and Animation", "Running", "Creativity"],
	    datasets: [
	        {
	            fillColor: "rgba(151,187,205,0.2)",
	            strokeColor: "rgba(151,187,205,1)",
	            pointColor: "rgba(151,187,205,1)",
	            pointStrokeColor: "#fff",
	            pointHighlightFill: "#fff",
	            pointHighlightStroke: "rgba(151,187,205,1)",
	            data: [70,50,85,60,90]
	        }
	    ]
	};
	var general = document.getElementById("general").getContext("2d");
	new Chart(general).Radar(data);
}

function loadProgrammingLanguagesData(){
	var barData1 = {
		labels : ["Java","HTML/CSS","C++","C","Python","Javascript"],
		datasets : [{
			fillColor : "#48A497",
			strokeColor : "#48A4D1",
			data : [95,90,75,70,50,40]
		}]
	}
	var languages = document.getElementById("languages").getContext("2d");
	new Chart(languages).Bar(barData1);
}

function loadLibrariesAndPlugins(){
	var barData4 = {
		labels : ["Bootstrap","JavaFX","jQuery","Chart.js","OpenGL","Allegro"],
		datasets : [{
			fillColor : "#48A497",
			strokeColor : "#48A4D1",
			data : [95,90,80,75,70,50]
		}]
	}
	var plugins = document.getElementById("plugins").getContext("2d");
	new Chart(plugins).Bar(barData4);
}

function loadDevelopersToolsData(){
	var barData2 = {
		labels : ["Eclipse","SceneBuilder","SourceTree","Unix","Git","Visual Studio","GameMakerStudio","Unity"],
		datasets : [{
			fillColor : "#48A497",
			strokeColor : "#48A4D1",
			data : [95,95,90,75,70,50,40,10]
		}]
	}
	var devTools = document.getElementById("devTools").getContext("2d");
	new Chart(devTools).Bar(barData2);
}

function loadDesignersToolsData(){
	var barData3 = {
		labels : ["Pencil and Paper", "Adobe Flash", "Photoshop", "Illustrator", "Pixlr"],
		datasets : [{
			fillColor : "#48A497",
			strokeColor : "#48A4D1",
			data : [100, 95,75,60,55]
		}]
	}
	var designTools = document.getElementById("designTools").getContext("2d");
	new Chart(designTools).Bar(barData3);
}

$(document).ready(main);